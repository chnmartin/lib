[Mocha](http://visionmedia.github.io/mocha/) reporter for WebStorm and other IntelliJ IDEs (IntelliJ IDEA, PhpStorm, RubyMine, PyCharm, etc).

No need to install it manually, it's bundled with [NodeJS](https://plugins.jetbrains.com/plugin/6098) plugin.
